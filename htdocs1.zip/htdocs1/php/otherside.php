<?php
include "menu.php";
// require "menu.php"; stop l'execusion
// require_once "menu.php";  force to not repeat for > one more tme 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="site.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"  />
    <title>document</title>
</head>
<body>
    <!-- start header-->
    <header class="container">
        <div id="cont">
            <div class="logo">worldcome</div>
            <nav>
                <a class="a" href="autres/autres.html" target="_blank">sign in</a>
                <a class="a" href="sign up/signup.html" target="_blank">sign up</a>
                <a class="a" href="">help</a>
                <a class="a" href="">contact</a>
            </nav>
        </div>
    </header>
    <!--end header-->
</body>
</html>
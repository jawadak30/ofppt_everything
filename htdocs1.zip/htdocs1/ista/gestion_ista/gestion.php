<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="gestion.css">
    <title>Document</title>
</head>
<body>
    <section>
      <nav>
        <div class="link" id="add-post">
          <h1>add post</h1>
        </div>
        <div class="link" id="users">
          <h1>users</h1>
        </div>
        <div class="link" id="emails">
          <h1>emails</h1>
        </div>
        <div class="link" id="courses">
          <h1>courses</h1>
        </div>
      </nav>
    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.min.js" ></script>
    <script src="gestion.js"></script>
</body>
</html>
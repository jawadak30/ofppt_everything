<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="site.css">
    <title>Document</title>
</head>
<body>
    <!--start the footer-->
    <footer class="container" id="z">
        <div class="anything">
            <div class="box-of-footer">
                <div class="line">
                    <h1>get to know us</h1>
                    <a class="ligne" href="">careers</a>
                    <a class="ligne" href="">blog</a>
                    <a class="ligne" href="">about worldcome</a>
                    <a class="ligne" href="">term and conditions for us</a>
                </div>
                <div class="line">
                    <h1>GALAXY payement products</h1>
                    <a class="ligne" href="">GALAXY busniness card</a>
                    <a class="ligne" href="">shop with points</a>
                    <a class="ligne" href="">reload your balance</a>
                </div>
                <div class="line">
                    <h1>let us help you</h1>
                    <a class="ligne" href="autres/autres.html">your account</a>
                    <a class="ligne" href="">your orders</a>
                    <a class="ligne" href="">shopping rates and policies</a>
                    <a class="ligne" href="">returns and replacements</a>
                    <a class="ligne" href="">world assistant</a>
                </div>
                <div class="lo"> 
                    <h1>GALAXY</h1>
                </div>
            </div>
        </div>
    </footer>
    <!--end the footer-->
</body>
</html>
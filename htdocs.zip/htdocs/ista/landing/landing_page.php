<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="landing_page.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <section>
        <aside>
            <div class="navigation">
                <ul>
                    <li>
                        <a href="#">
                            <span class="icon">
                                <ion-icon name="logo-apple"></ion-icon>
                            </span>
                            <span class="title">Brand Name</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="icon">
                                <ion-icon name="home-outline"></ion-icon>
                            </span>
                            <span class="title">Dashboard</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="icon">
                                <ion-icon name="people-outline"></ion-icon>
                            </span>
                            <span class="title">Customers</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="icon">
                                <ion-icon name="chatbubble-outline"></ion-icon>
                            </span>
                            <span class="title">Messages</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="icon">
                                <ion-icon name="help-outline"></ion-icon>
                            </span>
                            <span class="title">Help</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="icon">
                                <ion-icon name="settings-outline"></ion-icon>
                            </span>
                            <span class="title">Settings</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="icon">
                                <ion-icon name="lock-closed-outline"></ion-icon>
                            </span>
                            <span class="title">Password</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="icon">
                                <ion-icon name="log-out-outline"></ion-icon>
                            </span>
                            <span class="title">Sign Out</span>
                        </a>
                    </li>
                </ul>
            </div>
        </aside>
        <div class="inside">
            <div class="post">
                <img src="" alt="">
                <div class="footer_of_post">
                    <span></span>
                    <p class="description">

                    </p>
                    <i></i>
                </div>
            </div>
            <div class="post">
                <img src="" alt="">
                <div class="footer_of_post">
                    <span></span>
                    <p class="description">

                    </p>
                    <i></i>
                </div>
            </div>
            <div class="post">
                <img src="" alt="">
                <div class="footer_of_post">
                    <span></span>
                    <p class="description">

                    </p>
                    <i></i>
                </div>
            </div>
            <div class="post">
                <img src="" alt="">
                <div class="footer_of_post">
                    <span></span>
                    <p class="description">

                    </p>
                    <i></i>
                </div>
            </div>
            <div class="pagintaion">

            </div>
        </div>
    </section>
    <div class="aaa">
        
    </div>
    <script src="landing_page.js"></script>
</body>
</html>
<?php
define("myvar","welcome to php");
echo myvar;
echo "<br>";

const 




?>
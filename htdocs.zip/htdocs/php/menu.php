<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
    </header>
    <nav>
        <ul>
            <li><a href=""></a>mr</li>
            <li><a href=""></a>aka</li>
            <li><a href=""></a>ja</li>
            <li><a href=""></a>jawad</li>
            <li><a href=""></a>friv</li>
        </ul>
    </nav>
</body>
</html>
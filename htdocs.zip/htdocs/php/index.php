<?php
echo "date 1: ".date("d/M/Y")."</br>";
// echo "date 2: ".date("d-M-Y")."</br>";
// echo "date 3: ".date("d.M.Y")."</br>";